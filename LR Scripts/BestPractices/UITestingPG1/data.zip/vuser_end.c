vuser_end()
{

	/* OUT */

	return 0;
}