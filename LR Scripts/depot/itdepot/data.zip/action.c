Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=121", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/octet-stream", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("favicon.ico", 
		"URL=http://10.20.30.1:8090/favicon.ico", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/x-ico", 
		"Referer=http://10.20.30.1:8090/ips/block/webcat?cat=45&pl=1&lu=0&url=aHR0cDovL3RoZWl0ZGVwb3QuY29tLw~~", 
		"Snapshot=t2.inf", 
		LAST);

	lr_think_time(13);

	web_submit_data("httpclient.html", 
		"Action=http://10.20.30.1:8090/httpclient.html", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://10.20.30.1:8090/ips/block/webcat?cat=45&pl=1&lu=0&url=aHR0cDovL3RoZWl0ZGVwb3QuY29tLw~~", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=request_url", "Value=http://theitdepot.com/", ENDITEM, 
		LAST);

	web_concurrent_start(NULL);

	web_url("SophosSans-Regular.woff2", 
		"URL=http://10.20.30.1:8090/themes/SophosSans-Regular.woff2", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=http://10.20.30.1:8090/httpclient.html", 
		"Snapshot=t4.inf", 
		LAST);

	web_url("logo-sophos.png", 
		"URL=http://10.20.30.1:8090/images/logo-sophos.png", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=image/png", 
		"Referer=http://10.20.30.1:8090/httpclient.html", 
		"Snapshot=t5.inf", 
		LAST);

	web_url("SophosSans-Light.woff2", 
		"URL=http://10.20.30.1:8090/themes/SophosSans-Light.woff2", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=http://10.20.30.1:8090/httpclient.html", 
		"Snapshot=t6.inf", 
		LAST);

	web_url("ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNjESIAkJx3XhtGmLFhIFDeeNQA4SBQ3OQUx6IeVn-xF5cyIb", 
		"URL=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTIxLjAuNjE2Ny4xNjESIAkJx3XhtGmLFhIFDeeNQA4SBQ3OQUx6IeVn-xF5cyIb?alt=proto", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t7.inf", 
		LAST);

	web_concurrent_end(NULL);

	return 0;
}