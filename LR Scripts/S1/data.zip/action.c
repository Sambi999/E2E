Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_url("thinking-tester-contact-list.herokuapp.com", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t46.inf", 
		"Mode=HTML", 
		LAST);

	/* Login */

	lr_think_time(32);

	web_custom_request("login", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/users/login", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t47.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"email\":\"WWWXXX123@gmail.com\",\"password\":\"WWWXXX111\"}", 
		LAST);

	web_url("contactList", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/contactList", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://thinking-tester-contact-list.herokuapp.com/", 
		"Snapshot=t48.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("contacts", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/contacts", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t49.inf", 
		"Mode=HTML", 
		LAST);

	/* Logout */

	lr_think_time(12);

	web_url("logout", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/logout", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://thinking-tester-contact-list.herokuapp.com/contactList", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("logout_2", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/users/logout", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t51.inf", 
		"Mode=HTML", 
		"EncType=", 
		LAST);

	web_url("thinking-tester-contact-list.herokuapp.com_2", 
		"URL=http://thinking-tester-contact-list.herokuapp.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=http://thinking-tester-contact-list.herokuapp.com/logout", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}